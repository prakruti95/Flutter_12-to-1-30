<?php

 include('connect.php');

 $sql = "select * from products";
 
 $result = mysqli_query($con,$sql);
 $data2 = array();

while($row = mysqli_fetch_array($result))
{
    $data["id"] = $row["id"];
    $data["product_name"] = $row["product_name"];
    $data["product_price"] = $row["product_price"];
    $data["product_description"] = $row["product_description"];
    

   array_push($data2,$data);
}

 echo json_encode($data2);
mysqli_close($con);
?>