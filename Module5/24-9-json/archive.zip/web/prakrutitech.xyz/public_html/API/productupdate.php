<?php
 include('connect.php');

 $id = $_POST['id'];
 $pn = $_POST['product_name'];
 $pp = $_POST['product_price'];
 $pd = $_POST['product_description'];



$Sql_Query = "UPDATE products SET product_name='$pn' ,product_price='$pp',product_description='$pd' WHERE id = '$id'";

 if(mysqli_query($con,$Sql_Query))
{
 echo 'Record Updated Successfully';
}
else
{
 echo 'Something went wrong';
 }

 mysqli_close($con);
?>