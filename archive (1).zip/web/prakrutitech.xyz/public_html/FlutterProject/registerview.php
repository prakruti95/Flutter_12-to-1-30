<?php
    include('connect.php');
        
    $select= "SELECT * FROM project_signup";
    $result = mysqli_query($con,$select);
    
    $response= array();
         
    while ($row = mysqli_fetch_array($result))
    {
        $value = array();
        $value["id"] = $row["id"];
         $value["username"] = $row["username"];
          $value["password"] = $row["password"];
           $value["mobileno"] = $row["mobileno"];
            $value["identifier"] = $row["identifier"];
        
    
        array_push($response, $value);
    }
    echo json_encode($response);
?>