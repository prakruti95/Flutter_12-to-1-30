<?php

    define('HOST','localhost');
    define('USER','prak469910_prakruti');
    define('PASS','Tops?123');
    define('DB','prak469910_mydatabase');

    $con = mysqli_connect(HOST,USER,PASS,DB) or die('unable to connect');


?>
